using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace demo
{
    public partial class ProductForm : Form
    {
        private int? _productId;
        private string _articleNumber;
        private bool _isEditMode;
        private string _newPhotoPath = null;
        private string _oldPhotoName = null;
        private string _importPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "import");

        public ProductForm(int? productId = null)
        {
            InitializeComponent();
            _productId = productId;
            _isEditMode = productId != null;
            
            LoadComboBoxes();

            if (_isEditMode)
            {
                this.Text = "Редактирование товара";
                txtArticle.ReadOnly = true;
                LoadProductData();
            }
            else
            {
                this.Text = "Добавление товара";
                txtArticle.Text = "";
                txtArticle.ReadOnly = false;
                btnDelete.Visible = false;
            }
        }

        private void LoadComboBoxes()
        {
            try {
                var catTable = DatabaseContext.ExecuteQuery("SELECT DISTINCT Category FROM Product");
                foreach (DataRow r in catTable.Rows) cmbCategory.Items.Add(r[0]);

                var manTable = DatabaseContext.ExecuteQuery("SELECT DISTINCT Manufacturer FROM Product");
                foreach (DataRow r in manTable.Rows) cmbManufacturer.Items.Add(r[0]);
            } catch { }
        }

        private void LoadProductData()
        {
            try
            {
                string query = "SELECT * FROM Product WHERE ProductID = @ID";
                SqlParameter[] pars = { new SqlParameter("@ID", _productId) };
                DataTable dt = DatabaseContext.ExecuteQuery(query, pars);
                if (dt.Rows.Count > 0)
                {
                    DataRow r = dt.Rows[0];
                    txtArticle.Text = r["ProductArticleNumber"].ToString();
                    txtName.Text = r["ProductName"].ToString();
                    cmbCategory.Text = r["Category"].ToString();
                    txtDescription.Text = r["Description"].ToString();
                    cmbManufacturer.Text = r["Manufacturer"].ToString();
                    txtSupplier.Text = r["Supplier"].ToString();
                    txtUnit.Text = r["Unit"].ToString();
                    txtPrice.Text = r["Cost"].ToString();
                    txtDiscount.Text = r["DiscountAmount"].ToString();
                    txtStock.Text = r["QuantityInStock"].ToString();
                    
                    _oldPhotoName = r["Photo"].ToString();
                    LoadImageToPB(_oldPhotoName);
                }
            } catch (Exception ex) {
                MessageBox.Show("Ошибка загрузки: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadImageToPB(string photoName)
        {
            string path = System.IO.Path.Combine(_importPath, photoName ?? "");
            if (System.IO.File.Exists(path))
                pbPhoto.Image = Image.FromFile(path);
            else
                pbPhoto.Image = Image.FromFile(System.IO.Path.Combine(_importPath, "picture.png"));
        }

        private void btnChangePhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Images|*.jpg;*.png;*.jpeg";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                _newPhotoPath = ofd.FileName;
                pbPhoto.Image = Image.FromFile(_newPhotoPath);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateForm()) return;

            try {
                string savedPhotoName = _oldPhotoName;
                if (_newPhotoPath != null) {
                    savedPhotoName = SaveAndResizeImage(_newPhotoPath);
                    // Удаляем старое фото если оно было и изменилось
                    if (!string.IsNullOrEmpty(_oldPhotoName) && _oldPhotoName != "picture.png") {
                        try { System.IO.File.Delete(System.IO.Path.Combine(_importPath, _oldPhotoName)); } catch {}
                    }
                }

                if (_isEditMode) {
                    string sql = "UPDATE Product SET ProductName=@Name, Category=@Cat, Description=@Desc, Manufacturer=@Man, Supplier=@Sup, Unit=@Unit, Cost=@Cost, DiscountAmount=@Disc, QuantityInStock=@Stock, Photo=@Photo WHERE ProductID=@ID";
                    SqlParameter[] pars = GetParams(savedPhotoName);
                    Array.Resize(ref pars, pars.Length + 1);
                    pars[pars.Length - 1] = new SqlParameter("@ID", _productId);
                    DatabaseContext.ExecuteQuery(sql, pars);
                } else {
                    _articleNumber = txtArticle.Text.Trim();
                    if (string.IsNullOrEmpty(_articleNumber)) {
                        MessageBox.Show("Введите артикул", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    // Проверка на уникальность артикула
                    var check = DatabaseContext.ExecuteQuery("SELECT 1 FROM Product WHERE ProductArticleNumber = @Art", new SqlParameter[] { new SqlParameter("@Art", _articleNumber) });
                    if (check.Rows.Count > 0) {
                        MessageBox.Show("Товар с таким артикулом уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    string sql = "INSERT INTO Product (ProductArticleNumber, ProductName, Category, Description, Manufacturer, Supplier, Unit, Cost, DiscountAmount, QuantityInStock, Photo) VALUES (@Art, @Name, @Cat, @Desc, @Man, @Sup, @Unit, @Cost, @Disc, @Stock, @Photo)";
                    SqlParameter[] pars = GetParams(savedPhotoName);
                    DatabaseContext.ExecuteQuery(sql, pars);
                }

                MessageBox.Show("Данные сохранены успешно.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            } catch (Exception ex) {
                MessageBox.Show("Ошибка сохранения: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text)) { MessageBox.Show("Введите наименование", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            if (!decimal.TryParse(txtPrice.Text, out decimal p) || p < 0) { MessageBox.Show("Некорректная цена", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            if (!int.TryParse(txtStock.Text, out int s) || s < 0) { MessageBox.Show("Некорректное количество", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            return true;
        }

        private SqlParameter[] GetParams(string photo)
        {
            return new SqlParameter[] {
                new SqlParameter("@Art", _articleNumber),
                new SqlParameter("@Name", txtName.Text),
                new SqlParameter("@Cat", cmbCategory.Text),
                new SqlParameter("@Desc", txtDescription.Text),
                new SqlParameter("@Man", cmbManufacturer.Text),
                new SqlParameter("@Sup", txtSupplier.Text),
                new SqlParameter("@Unit", txtUnit.Text),
                new SqlParameter("@Cost", decimal.Parse(txtPrice.Text)),
                new SqlParameter("@Disc", byte.Parse(string.IsNullOrEmpty(txtDiscount.Text) ? "0" : txtDiscount.Text)),
                new SqlParameter("@Stock", int.Parse(txtStock.Text)),
                new SqlParameter("@Photo", photo ?? (object)DBNull.Value)
            };
        }

        private string SaveAndResizeImage(string sourcePath)
        {
            string fileName = System.IO.Path.GetFileName(sourcePath);
            string destPath = System.IO.Path.Combine(_importPath, fileName);
            
            using (Image img = Image.FromFile(sourcePath)) {
                using (Bitmap b = new Bitmap(img, new Size(300, 200))) {
                    b.Save(destPath);
                }
            }
            return fileName;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите удалить этот товар?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {
                try {
                    // Проверка на наличие в заказах
                    var check = DatabaseContext.ExecuteQuery("SELECT 1 FROM OrderProduct WHERE ProductID = @ID", new SqlParameter[] { new SqlParameter("@ID", _productId) });
                    if (check.Rows.Count > 0) {
                        MessageBox.Show("Нельзя удалить товар, который есть в заказе!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    DatabaseContext.ExecuteQuery("DELETE FROM Product WHERE ProductID = @ID", new SqlParameter[] { new SqlParameter("@ID", _productId) });
                    if (!string.IsNullOrEmpty(_oldPhotoName) && _oldPhotoName != "picture.png") {
                        try { System.IO.File.Delete(System.IO.Path.Combine(_importPath, _oldPhotoName)); } catch {}
                    }
                    
                    MessageBox.Show("Товар удален.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                } catch (Exception ex) {
                    MessageBox.Show("Ошибка удаления: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) { this.Close(); }
    }
}
