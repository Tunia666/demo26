# diplom-09.02.07-BRT <img width="1108" height="786" alt="demo_diagram" src="https://github.com/user-attachments/assets/5a33b0bb-a4b0-4b76-aa1f-96a7d0f35452" />
