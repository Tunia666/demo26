﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _0Demo
{
    public class Product
    {

        public int Id { get; set; }
        public string Article { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public string Manufacturer { get; set; }
        public string Supplier { get; set; }
        public decimal Price { get; set; }
        public string Unit { get; set; }
        public int StockQty { get; set; }
        public decimal DiscountPercent { get; set; }
        public string ImagePath { get; set; }   // тут будет "1.jpg" или "Resources\\images\\1.jpg"

    }
}
