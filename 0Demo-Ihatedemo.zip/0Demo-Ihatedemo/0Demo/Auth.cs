﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _0Demo
{
    public partial class Auth : Form
    {
        public Auth()
        {
            InitializeComponent();
        }
        Tovar tovar = new Tovar();
        static string connectString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=0Demo;Integrated Security=true";
        SqlConnection myConnection = new SqlConnection(connectString);

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string login = textBoxLogin.Text.Trim();
            string password = textBoxPass.Text;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите логин и пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectString))
                {
                    connection.Open();

                    string sql = @"
                        SELECT TOP 1
                            [Роль сотрудника] AS RoleName,
                            LTRIM(RTRIM(ISNULL([Фамилия],''))) + ' ' +
                            LTRIM(RTRIM(ISNULL([Имя],''))) + ' ' +
                            LTRIM(RTRIM(ISNULL([Отчество],''))) AS FIO
                        FROM [Пользователи]
                        WHERE [Логин] = @login AND [Пароль] = @password";

                    using (SqlCommand cmd = new SqlCommand(sql, connection))
                    {
                        cmd.Parameters.AddWithValue("@login", login);
                        cmd.Parameters.AddWithValue("@password", password);

                        using (var r = cmd.ExecuteReader())
                        {
                            if (r.Read())
                            {
                                string roleName = Convert.ToString(r["RoleName"]);
                                string fio = Convert.ToString(r["FIO"]);
                                LoginClass.UserName = string.IsNullOrWhiteSpace(fio) ? login : fio;
                                LoginClass.Role = ParseRole(roleName);
                                MessageBox.Show("Успешно вошли", "Успех!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                var tovar = new Tovar();
                                tovar.Show();

                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения/запроса:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private LoginClass.UserRole ParseRole(string roleName)
        {
            if (string.IsNullOrWhiteSpace(roleName))
                return LoginClass.UserRole.Guest;

            roleName = roleName.Trim().ToLower();
            if (roleName.Contains("админ")) return LoginClass.UserRole.Admin;
            if (roleName.Contains("менедж")) return LoginClass.UserRole.Manager;
            if (roleName.Contains("клиент")) return LoginClass.UserRole.Client;

            return LoginClass.UserRole.Guest;
        }

        private void buttonGuest_Click(object sender, EventArgs e)
        {
            tovar.Show();
            this.Hide();
        }
    }
}
