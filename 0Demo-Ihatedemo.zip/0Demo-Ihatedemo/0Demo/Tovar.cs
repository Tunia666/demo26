﻿using _0Demo.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0Demo
{
    public partial class Tovar : Form
    {
        [Obsolete]
        public Tovar()
        {
            InitializeComponent();
            this.Load += Form2_Load;
        }
        static string conn = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=0Demo;Integrated Security=true";
        [Obsolete]
        SqlConnection con = new SqlConnection(conn);
        private readonly ProductRepository _repo = new ProductRepository();

        [Obsolete]
        private void Form2_Load(object sender, EventArgs e)
        {
            ApplyRoleUi();
            ReloadProducts();

        }

        [Obsolete]
        public List<Product> GetAll()
        {
            var list = new List<Product>();
            using (var cmd = new SqlCommand(@"
        SELECT
            [id товара] AS Id,
            [Артикул] AS Article,
            [Наименование товара] AS Name,
            [Категория товара] AS Category,
            [Описание товара] AS Description,
            [Производитель] AS Manufacturer,
            [Поставщик] AS Supplier,
            CAST([Цена] AS decimal(18,2)) AS Price,
            [Единица измерения] AS Unit,
            [Кол-во на складе] AS StockQty,
            CAST(ISNULL([Действующая скидка],0) AS decimal(18,2)) AS DiscountPercent,
            [Фото] AS ImagePath
        FROM [dbo].[Товар]
    ", con))
            {
                con.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Product
                        {
                            Id = r.GetInt32(0),
                            Article = r.GetString(1),
                            Name = r.GetString(2),
                            Unit = r.GetString(8),
                            Supplier = r.GetString(6),
                            Manufacturer = r.GetString(5),
                            Category = r.GetString(3),
                            StockQty = r.GetInt32(9),
                            Price = r.GetDecimal(7),
                            DiscountPercent = r.GetDecimal(10),
                            Description = r.IsDBNull(4) ? "" : r.GetString(4),
                            ImagePath = r["ImagePath"] == DBNull.Value ? "" : Convert.ToString(r["ImagePath"])
                            //ImagePath = r.IsDBNull(11) ? "" : r.GetString(11),
                            //ImageBytes = r.IsDBNull(11) ? null : (byte[])r.GetValue(11),
                        });
                    }
                }
            }

            return list;
        }
        [Obsolete]
        public void ReloadProducts()
        {
            var items = _repo.GetAll();
            ShowProducts(items);
        }
        private void ShowProducts(List<Product> items)
        {
            flpProducts.SuspendLayout();
            flpProducts.Controls.Clear();

            foreach (var p in items)
            {
                var card = new ProductCard();
                card.SetData(p);
                flpProducts.Controls.Add(card);
            }

            flpProducts.ResumeLayout();
        }

        [Obsolete]
        public List<string> GetSuppliers()
        {
            var res = new List<string> { "Все поставщики" };

            using (var cmd = new SqlCommand(@"
                SELECT DISTINCT [Поставщик]
                FROM [dbo].[Товар]
                ORDER BY [Поставщик]
            ", con))
            {
                con.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                        res.Add(r.GetString(0));
                }
            }

            return res;
        }
        private void ApplyRoleUi()
        {
            bool allowed = LoginClass.Role == LoginClass.UserRole.Admin
                           || LoginClass.Role == LoginClass.UserRole.Manager;


            pTools.Visible = allowed;   // панель поиска/поставщик/остаток

            // если нужно ещё что-то закрывать 
            // txtSearch.Visible = allowed;
            // cbSupplier.Visible = allowed;
            // cbSortQty.Visible = allowed;

            // если место оставить, но не давать нажать:
            // pTools.Enabled = allowed;
        }
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
