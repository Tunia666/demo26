﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _0Demo
{
    internal class LoginClass
    {
        public static UserRole Role { get; set; } = UserRole.Guest;
        public static string UserName { get; set; } = "Гость";

        public enum UserRole
        {
            Guest,
            Client,
            Manager,
            Admin
        }
    }
}
