﻿namespace _0Demo
{
    partial class ProductCard
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            lblQtyValue = new Label();
            lblUnitValue = new Label();
            lblSupplierValue = new Label();
            lblManufacturerValue = new Label();
            lblDescValue = new Label();
            label9 = new Label();
            lblHeader = new Label();
            Description = new Label();
            Manufacturer = new Label();
            Suppler = new Label();
            Price = new Label();
            Unit = new Label();
            StockQty = new Label();
            tableLayoutPanel2 = new TableLayoutPanel();
            lblNewPrice = new Label();
            lblOldPrice = new Label();
            panel1 = new Panel();
            lblDiscountValue = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Left;
            pictureBox1.Image = Properties.Resources.picture;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(201, 164);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 429F));
            tableLayoutPanel1.Controls.Add(lblQtyValue, 1, 6);
            tableLayoutPanel1.Controls.Add(lblUnitValue, 1, 5);
            tableLayoutPanel1.Controls.Add(lblSupplierValue, 1, 3);
            tableLayoutPanel1.Controls.Add(lblManufacturerValue, 1, 2);
            tableLayoutPanel1.Controls.Add(lblDescValue, 1, 1);
            tableLayoutPanel1.Controls.Add(label9, 1, 0);
            tableLayoutPanel1.Controls.Add(lblHeader, 0, 0);
            tableLayoutPanel1.Controls.Add(Description, 0, 1);
            tableLayoutPanel1.Controls.Add(Manufacturer, 0, 2);
            tableLayoutPanel1.Controls.Add(Suppler, 0, 3);
            tableLayoutPanel1.Controls.Add(Price, 0, 4);
            tableLayoutPanel1.Controls.Add(Unit, 0, 5);
            tableLayoutPanel1.Controls.Add(StockQty, 0, 6);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 1, 4);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(201, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 7;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(739, 164);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // lblQtyValue
            // 
            lblQtyValue.AutoSize = true;
            lblQtyValue.Location = new Point(313, 144);
            lblQtyValue.Name = "lblQtyValue";
            lblQtyValue.Size = new Size(20, 15);
            lblQtyValue.TabIndex = 13;
            lblQtyValue.Text = "txt";
            // 
            // lblUnitValue
            // 
            lblUnitValue.AutoSize = true;
            lblUnitValue.Location = new Point(313, 124);
            lblUnitValue.Name = "lblUnitValue";
            lblUnitValue.Size = new Size(20, 15);
            lblUnitValue.TabIndex = 12;
            lblUnitValue.Text = "txt";
            // 
            // lblSupplierValue
            // 
            lblSupplierValue.AutoSize = true;
            lblSupplierValue.Location = new Point(313, 84);
            lblSupplierValue.Name = "lblSupplierValue";
            lblSupplierValue.Size = new Size(20, 15);
            lblSupplierValue.TabIndex = 11;
            lblSupplierValue.Text = "txt";
            // 
            // lblManufacturerValue
            // 
            lblManufacturerValue.AutoSize = true;
            lblManufacturerValue.Location = new Point(313, 64);
            lblManufacturerValue.Name = "lblManufacturerValue";
            lblManufacturerValue.Size = new Size(20, 15);
            lblManufacturerValue.TabIndex = 10;
            lblManufacturerValue.Text = "txt";
            // 
            // lblDescValue
            // 
            lblDescValue.AutoSize = true;
            lblDescValue.Location = new Point(313, 32);
            lblDescValue.Name = "lblDescValue";
            lblDescValue.Size = new Size(20, 15);
            lblDescValue.TabIndex = 9;
            lblDescValue.Text = "txt";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(313, 0);
            label9.Name = "label9";
            label9.Size = new Size(0, 15);
            label9.TabIndex = 7;
            // 
            // lblHeader
            // 
            lblHeader.AutoSize = true;
            lblHeader.Location = new Point(3, 0);
            lblHeader.Name = "lblHeader";
            lblHeader.Size = new Size(195, 15);
            lblHeader.TabIndex = 0;
            lblHeader.Text = "Категория | Наименование товара";
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(3, 32);
            Description.Name = "Description";
            Description.Size = new Size(62, 15);
            Description.TabIndex = 1;
            Description.Text = "Описание";
            // 
            // Manufacturer
            // 
            Manufacturer.AutoSize = true;
            Manufacturer.Location = new Point(3, 64);
            Manufacturer.Name = "Manufacturer";
            Manufacturer.Size = new Size(92, 15);
            Manufacturer.TabIndex = 2;
            Manufacturer.Text = "Производитель";
            // 
            // Suppler
            // 
            Suppler.AutoSize = true;
            Suppler.Location = new Point(3, 84);
            Suppler.Name = "Suppler";
            Suppler.Size = new Size(70, 15);
            Suppler.TabIndex = 3;
            Suppler.Text = "Поставщик";
            // 
            // Price
            // 
            Price.AutoSize = true;
            Price.Location = new Point(3, 104);
            Price.Name = "Price";
            Price.Size = new Size(35, 15);
            Price.TabIndex = 4;
            Price.Text = "Цена";
            // 
            // Unit
            // 
            Unit.AutoSize = true;
            Unit.Location = new Point(3, 124);
            Unit.Name = "Unit";
            Unit.Size = new Size(52, 15);
            Unit.TabIndex = 5;
            Unit.Text = "Еденица";
            // 
            // StockQty
            // 
            StockQty.AutoSize = true;
            StockQty.Location = new Point(3, 144);
            StockQty.Name = "StockQty";
            StockQty.Size = new Size(79, 15);
            StockQty.TabIndex = 6;
            StockQty.Text = "Колличество";
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(lblNewPrice, 1, 0);
            tableLayoutPanel2.Controls.Add(lblOldPrice, 0, 0);
            tableLayoutPanel2.Location = new Point(313, 107);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(420, 14);
            tableLayoutPanel2.TabIndex = 8;
            // 
            // lblNewPrice
            // 
            lblNewPrice.AutoSize = true;
            lblNewPrice.Location = new Point(213, 0);
            lblNewPrice.Name = "lblNewPrice";
            lblNewPrice.Size = new Size(72, 14);
            lblNewPrice.TabIndex = 1;
            lblNewPrice.Text = "Новая Цена";
            // 
            // lblOldPrice
            // 
            lblOldPrice.AutoSize = true;
            lblOldPrice.Location = new Point(3, 0);
            lblOldPrice.Name = "lblOldPrice";
            lblOldPrice.Size = new Size(79, 14);
            lblOldPrice.TabIndex = 0;
            lblOldPrice.Text = "Старая Цена:";
            // 
            // panel1
            // 
            panel1.Controls.Add(lblDiscountValue);
            panel1.Dock = DockStyle.Right;
            panel1.Location = new Point(940, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(200, 164);
            panel1.TabIndex = 2;
            // 
            // lblDiscountValue
            // 
            lblDiscountValue.AutoSize = true;
            lblDiscountValue.Location = new Point(3, 0);
            lblDiscountValue.Name = "lblDiscountValue";
            lblDiscountValue.Size = new Size(38, 15);
            lblDiscountValue.TabIndex = 0;
            lblDiscountValue.Text = "label1";
            // 
            // ProductCard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel1);
            Controls.Add(pictureBox1);
            Name = "ProductCard";
            Size = new Size(1140, 164);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel1;
        private Label lblDiscountValue;
        private Label label14;
        private Label lblHeader;
        private Label label9;
        private Label Description;
        private Label Manufacturer;
        private Label Suppler;
        private Label Price;
        private Label Unit;
        private Label StockQty;
        private TableLayoutPanel tableLayoutPanel2;
        private Label lblNewPrice;
        private Label lblOldPrice;
        private Label lblQtyValue;
        private Label lblUnitValue;
        private Label lblSupplierValue;
        private Label lblManufacturerValue;
        private Label lblDescValue;
    }
}
