﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace _0Demo.Data
{
    internal class ProductRepository
    {
        static string conn = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=0Demo;Integrated Security=true";

        [Obsolete]
        public List<Product> GetAll()
        {
            var list = new List<Product>();
            using (SqlConnection con = new SqlConnection(conn))
            using (var cmd = new SqlCommand(@"
                SELECT
                    [id] AS Id,
                    [article] AS Article,
                    [name] AS Name,
                    [category] AS Category,
                    [description] AS Description,
                    [Manufacturer] AS Manufacturer,
                    [supplier] AS Supplier,
                    CAST([price] AS decimal(18,2)) AS Price,
                    [unit] AS Unit,
                    [stock_quantity] AS StockQty,
                    CAST(ISNULL([discount],0) AS decimal(18,2)) AS DiscountPercent,
                    [photo] AS ImagePath
                FROM [dbo].[products];
            ", con))
            {
                con.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Product
                        {
                            Id = Convert.ToInt32(r["Id"]),
                            Article = Convert.ToString(r["Article"]),
                            Name = Convert.ToString(r["Name"]),
                            Category = Convert.ToString(r["Category"]),
                            Description = Convert.ToString(r["Description"]),
                            Manufacturer = Convert.ToString(r["Manufacturer"]),
                            Supplier = Convert.ToString(r["Supplier"]),
                            Price = Convert.ToDecimal(r["Price"]),
                            Unit = Convert.ToString(r["Unit"]),
                            StockQty = Convert.ToInt32(r["StockQty"]),
                            DiscountPercent = Convert.ToDecimal(r["DiscountPercent"]),
                            ImagePath = Convert.ToString(r["ImagePath"]),
                        });
                    }
                }

            }

            return list;
        }
    }
}
