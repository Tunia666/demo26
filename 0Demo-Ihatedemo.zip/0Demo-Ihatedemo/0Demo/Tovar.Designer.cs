﻿namespace _0Demo
{
    public partial class Tovar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            flpProducts = new FlowLayoutPanel();
            pTop = new Panel();
            buttonExit = new Button();
            labelUser = new Label();
            label1 = new Label();
            pTools = new Panel();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            textBox1 = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            pTop.SuspendLayout();
            pTools.SuspendLayout();
            SuspendLayout();
            // 
            // flpProducts
            // 
            flpProducts.Dock = DockStyle.Fill;
            flpProducts.Location = new Point(0, 129);
            flpProducts.Name = "flpProducts";
            flpProducts.Size = new Size(1140, 369);
            flpProducts.TabIndex = 0;
            // 
            // pTop
            // 
            pTop.Controls.Add(buttonExit);
            pTop.Controls.Add(labelUser);
            pTop.Controls.Add(label1);
            pTop.Dock = DockStyle.Top;
            pTop.Location = new Point(0, 0);
            pTop.Name = "pTop";
            pTop.Size = new Size(1140, 63);
            pTop.TabIndex = 1;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(1044, 5);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(75, 23);
            buttonExit.TabIndex = 3;
            buttonExit.Text = "exit";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += button1_Click;
            // 
            // labelUser
            // 
            labelUser.AutoSize = true;
            labelUser.Location = new Point(956, 34);
            labelUser.Name = "labelUser";
            labelUser.Size = new Size(85, 15);
            labelUser.TabIndex = 1;
            labelUser.Text = "пользователь:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(95, 15);
            label1.TabIndex = 0;
            label1.Text = "Список товаров";
            // 
            // pTools
            // 
            pTools.Controls.Add(button2);
            pTools.Controls.Add(button1);
            pTools.Controls.Add(comboBox2);
            pTools.Controls.Add(comboBox1);
            pTools.Controls.Add(textBox1);
            pTools.Controls.Add(label5);
            pTools.Controls.Add(label4);
            pTools.Controls.Add(label3);
            pTools.Dock = DockStyle.Top;
            pTools.Location = new Point(0, 63);
            pTools.Name = "pTools";
            pTools.Size = new Size(1140, 66);
            pTools.TabIndex = 2;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(689, 22);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(159, 23);
            comboBox2.TabIndex = 7;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(447, 22);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(159, 23);
            comboBox1.TabIndex = 6;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(58, 24);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(329, 23);
            textBox1.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(612, 24);
            label5.Name = "label5";
            label5.Size = new Size(71, 15);
            label5.TabIndex = 4;
            label5.Text = "сортировка";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(393, 27);
            label4.Name = "label4";
            label4.Size = new Size(48, 15);
            label4.TabIndex = 3;
            label4.Text = "фильтр";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 25);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 2;
            label3.Text = "поиск";
            // 
            // button1
            // 
            button1.Location = new Point(854, 22);
            button1.Name = "button1";
            button1.Size = new Size(131, 23);
            button1.TabIndex = 8;
            button1.Text = "Добавить товар";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(1026, 24);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 9;
            button2.Text = "Заказы";
            button2.UseVisualStyleBackColor = true;
            // 
            // Tovar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1140, 498);
            Controls.Add(flpProducts);
            Controls.Add(pTools);
            Controls.Add(pTop);
            Name = "Tovar";
            Text = "Tovar";
            pTop.ResumeLayout(false);
            pTop.PerformLayout();
            pTools.ResumeLayout(false);
            pTools.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel flpProducts;
        private Panel pTop;
        private Panel pTools;
        private Label labelUser;
        private Label label1;
        private Label label5;
        private Label label4;
        private Label label3;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private TextBox textBox1;
        private Button buttonExit;
        private Button button2;
        private Button button1;
    }
}