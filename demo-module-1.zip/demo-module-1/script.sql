USE [master]
GO
CREATE DATABASE [Trade]
GO
USE [Trade]
GO

CREATE TABLE [dbo].[PickupPoint](
    [PointID] [int] IDENTITY(1,1) NOT NULL,
    [Index] [nvarchar](50) NOT NULL,
    [City] [nvarchar](100) NOT NULL,
    [Street] [nvarchar](100) NOT NULL,
    [House] [nvarchar](50) NULL,
    PRIMARY KEY CLUSTERED ([PointID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Product](
    [ProductID] [int] IDENTITY(1,1) NOT NULL,
    [ProductArticleNumber] [nvarchar](100) NOT NULL UNIQUE,
    [ProductName] [nvarchar](max) NOT NULL,
    [Unit] [nvarchar](50) NOT NULL,
    [Cost] [decimal](18, 2) NOT NULL,
    [Manufacturer] [nvarchar](max) NOT NULL,
    [Supplier] [nvarchar](max) NOT NULL,
    [Category] [nvarchar](max) NOT NULL,
    [DiscountAmount] [tinyint] NULL,
    [QuantityInStock] [int] NOT NULL,
    [Description] [nvarchar](max) NULL,
    [Photo] [nvarchar](max) NULL,
    PRIMARY KEY CLUSTERED ([ProductID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[User](
    [UserID] [int] IDENTITY(1,1) NOT NULL,
    [Role] [nvarchar](100) NOT NULL,
    [UserSurname] [nvarchar](100) NOT NULL,
    [UserName] [nvarchar](100) NOT NULL,
    [UserPatronymic] [nvarchar](100) NULL,
    [Login] [nvarchar](100) NOT NULL,
    [Password] [nvarchar](100) NOT NULL,
    PRIMARY KEY CLUSTERED ([UserID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Order](
    [OrderID] [int] IDENTITY(1,1) NOT NULL,
    [OrderStatus] [nvarchar](100) NOT NULL,
    [OrderDate] [datetime] NOT NULL,
    [DeliveryDate] [datetime] NOT NULL,
    [PickupPointID] [int] NOT NULL,
    [OrderCode] [int] NOT NULL,
    [ClientSurname] [nvarchar](100) NULL,
    [ClientName] [nvarchar](100) NULL,
    [ClientPatronymic] [nvarchar](100) NULL,
    PRIMARY KEY CLUSTERED ([OrderID] ASC)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[OrderProduct](
    [OrderProductID] [int] IDENTITY(1,1) NOT NULL,
    [OrderID] [int] NOT NULL,
    [ProductID] [int] NOT NULL,
    [ProductCount] [int] NOT NULL,
    PRIMARY KEY CLUSTERED ([OrderProductID] ASC)
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Order] WITH CHECK ADD CONSTRAINT [FK_Order_PickupPoint] FOREIGN KEY([PickupPointID]) REFERENCES [dbo].[PickupPoint] ([PointID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Order] CHECK CONSTRAINT [FK_Order_PickupPoint]
GO

ALTER TABLE [dbo].[OrderProduct] WITH CHECK ADD CONSTRAINT [FK_OrderProduct_Order] FOREIGN KEY([OrderID]) REFERENCES [dbo].[Order] ([OrderID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[OrderProduct] CHECK CONSTRAINT [FK_OrderProduct_Order]
GO

ALTER TABLE [dbo].[OrderProduct] WITH CHECK ADD CONSTRAINT [FK_OrderProduct_Product] FOREIGN KEY([ProductID]) REFERENCES [dbo].[Product] ([ProductID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[OrderProduct] CHECK CONSTRAINT [FK_OrderProduct_Product]
GO