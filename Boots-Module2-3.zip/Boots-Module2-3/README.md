<img width="1421" height="771" alt="Diagram" src="https://github.com/user-attachments/assets/1df99b40-0c30-4a9d-8aea-7f5377448cbf" />
