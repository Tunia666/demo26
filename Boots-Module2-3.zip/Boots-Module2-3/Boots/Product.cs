﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boots
{
    public class Product
    {
        public int Id { get; set; }
        public string Articul { get; set; }
        public string Name { get; set; }
        public string Unit { get; set; }
        public decimal Price { get; set; }
        public string Manufacturer { get; set; }
        public string Supplier { get; set; }
        public string Category { get; set; }
        public decimal DiscontPercent { get; set; }
        public int StrockQty { get; set; }
        public string Discription { get; set; }
        public string ImagePath { get; set; }

    }
}
