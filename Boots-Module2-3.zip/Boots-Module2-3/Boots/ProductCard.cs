﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Boots
{
    public partial class ProductCard : UserControl
    {
        public ProductCard()
        {
            InitializeComponent();
        }

        public int ProductId { get; set; }

        public void SetData(Product p)
        {
            if (p == null) throw new ArgumentNullException(nameof(p));
            ProductId = p.Id;

            labelHeader.Text = $"{p.Category} | {p.Name}";
            labelOpisanie.Text = p.Discription;
            labelProizvod.Text = p.Manufacturer;
            labelPostav.Text = p.Supplier;
            labelEd.Text = p.Unit;
            labelDiscountValue.Text = $"{p.DiscontPercent:0.#}%";

            // Отображение скидки
            labelDiscountValue.Text = $"Действующая скидка: {p.DiscontPercent:0.#}%";

            if (p.DiscontPercent > 0)
            {
                // Старая цена (зачёркнутая)
                labelPrice.Visible = true;
                labelPrice.Text = $"{p.Price:0.00} р.";
                labelPrice.ForeColor = Color.Red;
                labelPrice.Font = new Font(labelPrice.Font, FontStyle.Strikeout);

                // Новая цена со скидкой
                decimal newPrice = p.Price * (1 - p.DiscontPercent / 100m);
                labelPrice2.Visible = true;
                labelPrice2.Text = $"{newPrice:0.00} р.";
                labelPrice2.ForeColor = Color.Black;
            }
            else
            {
                labelPrice.Visible = false;
                labelPrice2.Visible = false;
            }

            // Окраска карточки в зависимости от остатка и скидки
            if (p.StrockQty <= 0)
                BackColor = Color.LightBlue;          // Нет в наличии
            else if (p.DiscontPercent > 15)
                BackColor = ColorTranslator.FromHtml("#2E8B57"); // Большая скидка >15%
            else
                BackColor = Color.White;
        }

        private void ProductCard_Load(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
    }
}