﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Boots
{
    public partial class Login : Form
    {
        private static readonly string connectionString =
            @"Server=alla\allooo;Database=Магазин обувки;Trusted_Connection=True;";

        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = loginBox.Text.Trim();
            string password = PasswordBox.Text;

            if (string.IsNullOrWhiteSpace(login))
            {
                MessageBox.Show("Введите логин.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Правильный запрос: нет столбца "Роль", только "Роль сотрудника"
                    string sql = @"
                        SELECT TOP 1 
                            [Имя],
                            [Роль сотрудника],
                            [Пароль]
                        FROM [Пользователи$]
                        WHERE [Логин] = @login";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@login", login);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Проверка пароля (учитывая NULL)
                                object dbPasswordObj = reader["Пароль"];
                                string dbPassword = dbPasswordObj == DBNull.Value ? null : dbPasswordObj.ToString();

                                bool passwordOk;
                                if (dbPassword == null)
                                    passwordOk = string.IsNullOrEmpty(password);
                                else
                                    passwordOk = dbPassword == password;

                                if (!passwordOk)
                                {
                                    MessageBox.Show("Неверный пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }

                                string dbName = reader["Имя"] == DBNull.Value ? "" : reader["Имя"].ToString();
                                string roleName = reader["Роль сотрудника"] == DBNull.Value ? "" : reader["Роль сотрудника"].ToString();

                                LoginClass.UserName = string.IsNullOrWhiteSpace(dbName) ? login : dbName;
                                LoginClass.Role = ParseRole(roleName);

                                OpenMainForm();
                            }
                            else
                            {
                                MessageBox.Show("Пользователь не найден.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void guestButton_Click(object sender, EventArgs e)
        {
            LoginClass.UserName = "Гость";
            LoginClass.Role = LoginClass.UserRole.Guest;
            OpenMainForm();
        }

        private void OpenMainForm()
        {
            Tovar tovarForm = new Tovar();
            tovarForm.Show();
            this.Hide();
            tovarForm.FormClosed += (s, args) => this.Close();
        }

        private LoginClass.UserRole ParseRole(string roleName)
        {
            if (string.IsNullOrWhiteSpace(roleName))
                return LoginClass.UserRole.Client;

            roleName = roleName.Trim().ToLower();
            if (roleName.Contains("админ")) return LoginClass.UserRole.Admin;
            if (roleName.Contains("менедж")) return LoginClass.UserRole.Manager;
            if (roleName.Contains("клиент")) return LoginClass.UserRole.Client;

            return LoginClass.UserRole.Client;
        }
        private void PasswordBox_TextChanged(object sender, EventArgs e)
        {
            // Можно оставить пустым, если не нужна логика при изменении текста пароля
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Можно оставить пустым
        }
    }
}