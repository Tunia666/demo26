﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Boots.Data
{
    public class ProductRepository
    {
        private static string connectString = @"Server=alla\allooo;Database=Магазин обувки;Trusted_Connection=True;";

        public List<Product> GetAll()
        {
            var list = new List<Product>();
            using (SqlConnection myConnection = new SqlConnection(connectString))
            using (var cmd = new SqlCommand(@"
                SELECT 
                    [ID Товара] AS Id,
                    [Артикул] AS Articul,
                    [Наименование товара] AS Name,
                    [Единица измерения] AS Unit,
                    CAST([Цена] AS decimal(18,2)) AS Price,
                    [Поставщик] AS Supplier,
                    [Производитель] AS Manufacturer,
                    [Категория товара] AS Category,
                    CAST(ISNULL([Действующая скидка], 0) AS decimal(18,2)) AS DiscontPercent,
                    [Кол-во на складе] AS StrockQty,
                    [Описание товара] AS Discription,
                    [Фото] AS ImagePath
                FROM [dbo].[Товары$];", myConnection))
            {
                myConnection.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Product
                        {
                            Id = Convert.ToInt32(r["Id"]),
                            Articul = Convert.ToString(r["Articul"]),
                            Name = Convert.ToString(r["Name"]),
                            Category = Convert.ToString(r["Category"]),
                            Discription = Convert.ToString(r["Discription"]),
                            Manufacturer = Convert.ToString(r["Manufacturer"]),
                            Supplier = Convert.ToString(r["Supplier"]),
                            Price = Convert.ToDecimal(r["Price"]),
                            Unit = Convert.ToString(r["Unit"]),
                            StrockQty = Convert.ToInt32(r["StrockQty"]),
                            DiscontPercent = Convert.ToDecimal(r["DiscontPercent"]),
                            ImagePath = Convert.ToString(r["ImagePath"])
                        });
                    }
                }
            }
            return list;
        }
    }
}