﻿namespace Boots
{
    partial class ProductCard
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.pRight = new System.Windows.Forms.Panel();
            this.labelDiscountValue = new System.Windows.Forms.Label();
            this.Tip = new System.Windows.Forms.TableLayoutPanel();
            this.labelKol2 = new System.Windows.Forms.Label();
            this.labelKol = new System.Windows.Forms.Label();
            this.labelEd2 = new System.Windows.Forms.Label();
            this.labelEd = new System.Windows.Forms.Label();
            this.labelPrice2 = new System.Windows.Forms.Label();
            this.labelPrice = new System.Windows.Forms.Label();
            this.labelPostav2 = new System.Windows.Forms.Label();
            this.labelPostav = new System.Windows.Forms.Label();
            this.labelProizvod2 = new System.Windows.Forms.Label();
            this.labelProizvod = new System.Windows.Forms.Label();
            this.labelOpisanie2 = new System.Windows.Forms.Label();
            this.labelHeader2 = new System.Windows.Forms.Label();
            this.labelHeader = new System.Windows.Forms.Label();
            this.labelOpisanie = new System.Windows.Forms.Label();
            this.pictureBoxPhoto = new System.Windows.Forms.PictureBox();
            this.pRight.SuspendLayout();
            this.Tip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // pRight
            // 
            this.pRight.Controls.Add(this.labelDiscountValue);
            this.pRight.Location = new System.Drawing.Point(725, 3);
            this.pRight.Name = "pRight";
            this.pRight.Size = new System.Drawing.Size(242, 168);
            this.pRight.TabIndex = 0;
            this.pRight.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // labelDiscountValue
            // 
            this.labelDiscountValue.AutoSize = true;
            this.labelDiscountValue.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDiscountValue.Location = new System.Drawing.Point(3, 0);
            this.labelDiscountValue.Name = "labelDiscountValue";
            this.labelDiscountValue.Size = new System.Drawing.Size(115, 15);
            this.labelDiscountValue.TabIndex = 4;
            this.labelDiscountValue.Text = "Действующая скидка";
            // 
            // Tip
            // 
            this.Tip.ColumnCount = 2;
            this.Tip.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Tip.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Tip.Controls.Add(this.labelHeader2, 1, 0);
            this.Tip.Controls.Add(this.labelHeader, 0, 0);
            this.Tip.Controls.Add(this.labelKol, 1, 6);
            this.Tip.Controls.Add(this.labelKol2, 0, 6);
            this.Tip.Controls.Add(this.labelEd, 1, 5);
            this.Tip.Controls.Add(this.labelEd2, 0, 5);
            this.Tip.Controls.Add(this.labelPrice, 1, 4);
            this.Tip.Controls.Add(this.labelPrice2, 0, 4);
            this.Tip.Controls.Add(this.labelPostav, 1, 3);
            this.Tip.Controls.Add(this.labelPostav2, 0, 3);
            this.Tip.Controls.Add(this.labelProizvod, 1, 2);
            this.Tip.Controls.Add(this.labelProizvod2, 0, 2);
            this.Tip.Controls.Add(this.labelOpisanie2, 1, 1);
            this.Tip.Controls.Add(this.labelOpisanie, 0, 1);
            this.Tip.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Tip.Location = new System.Drawing.Point(161, 3);
            this.Tip.Name = "Tip";
            this.Tip.RowCount = 7;
            this.Tip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.17647F));
            this.Tip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 58.82353F));
            this.Tip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.Tip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.Tip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.Tip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.Tip.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.Tip.Size = new System.Drawing.Size(549, 168);
            this.Tip.TabIndex = 2;
            // 
            // labelKol2
            // 
            this.labelKol2.AutoSize = true;
            this.labelKol2.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelKol2.Location = new System.Drawing.Point(3, 147);
            this.labelKol2.Name = "labelKol2";
            this.labelKol2.Size = new System.Drawing.Size(65, 15);
            this.labelKol2.TabIndex = 13;
            this.labelKol2.Text = "Количество";
            // 
            // labelKol
            // 
            this.labelKol.AutoSize = true;
            this.labelKol.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelKol.Location = new System.Drawing.Point(277, 147);
            this.labelKol.Name = "labelKol";
            this.labelKol.Size = new System.Drawing.Size(65, 15);
            this.labelKol.TabIndex = 12;
            this.labelKol.Text = "Количество";
            // 
            // labelEd2
            // 
            this.labelEd2.AutoSize = true;
            this.labelEd2.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelEd2.Location = new System.Drawing.Point(3, 127);
            this.labelEd2.Name = "labelEd2";
            this.labelEd2.Size = new System.Drawing.Size(49, 15);
            this.labelEd2.TabIndex = 11;
            this.labelEd2.Text = "Единица";
            // 
            // labelEd
            // 
            this.labelEd.AutoSize = true;
            this.labelEd.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelEd.Location = new System.Drawing.Point(277, 127);
            this.labelEd.Name = "labelEd";
            this.labelEd.Size = new System.Drawing.Size(49, 15);
            this.labelEd.TabIndex = 10;
            this.labelEd.Text = "Единица";
            // 
            // labelPrice2
            // 
            this.labelPrice2.AutoSize = true;
            this.labelPrice2.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPrice2.Location = new System.Drawing.Point(3, 101);
            this.labelPrice2.Name = "labelPrice2";
            this.labelPrice2.Size = new System.Drawing.Size(32, 15);
            this.labelPrice2.TabIndex = 9;
            this.labelPrice2.Text = "Цена";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPrice.Location = new System.Drawing.Point(277, 101);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(32, 15);
            this.labelPrice.TabIndex = 8;
            this.labelPrice.Text = "Цена";
            // 
            // labelPostav2
            // 
            this.labelPostav2.AutoSize = true;
            this.labelPostav2.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPostav2.Location = new System.Drawing.Point(3, 76);
            this.labelPostav2.Name = "labelPostav2";
            this.labelPostav2.Size = new System.Drawing.Size(64, 15);
            this.labelPostav2.TabIndex = 7;
            this.labelPostav2.Text = "Поставщик";
            // 
            // labelPostav
            // 
            this.labelPostav.AutoSize = true;
            this.labelPostav.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPostav.Location = new System.Drawing.Point(277, 76);
            this.labelPostav.Name = "labelPostav";
            this.labelPostav.Size = new System.Drawing.Size(64, 15);
            this.labelPostav.TabIndex = 6;
            this.labelPostav.Text = "Поставщик";
            // 
            // labelProizvod2
            // 
            this.labelProizvod2.AutoSize = true;
            this.labelProizvod2.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProizvod2.Location = new System.Drawing.Point(3, 48);
            this.labelProizvod2.Name = "labelProizvod2";
            this.labelProizvod2.Size = new System.Drawing.Size(86, 15);
            this.labelProizvod2.TabIndex = 5;
            this.labelProizvod2.Text = "Производитель";
            // 
            // labelProizvod
            // 
            this.labelProizvod.AutoSize = true;
            this.labelProizvod.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProizvod.Location = new System.Drawing.Point(277, 48);
            this.labelProizvod.Name = "labelProizvod";
            this.labelProizvod.Size = new System.Drawing.Size(86, 15);
            this.labelProizvod.TabIndex = 4;
            this.labelProizvod.Text = "Производитель";
            // 
            // labelOpisanie2
            // 
            this.labelOpisanie2.AutoSize = true;
            this.labelOpisanie2.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelOpisanie2.Location = new System.Drawing.Point(277, 20);
            this.labelOpisanie2.Name = "labelOpisanie2";
            this.labelOpisanie2.Size = new System.Drawing.Size(55, 15);
            this.labelOpisanie2.TabIndex = 3;
            this.labelOpisanie2.Text = "Описание";
            // 
            // labelHeader2
            // 
            this.labelHeader2.AutoSize = true;
            this.labelHeader2.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelHeader2.Location = new System.Drawing.Point(277, 0);
            this.labelHeader2.Name = "labelHeader2";
            this.labelHeader2.Size = new System.Drawing.Size(198, 15);
            this.labelHeader2.TabIndex = 1;
            this.labelHeader2.Text = "Категория | Наименование товара";
            // 
            // labelHeader
            // 
            this.labelHeader.AutoSize = true;
            this.labelHeader.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelHeader.Location = new System.Drawing.Point(3, 0);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new System.Drawing.Size(198, 15);
            this.labelHeader.TabIndex = 0;
            this.labelHeader.Text = "Категория | Наименование товара";
            // 
            // labelOpisanie
            // 
            this.labelOpisanie.AutoSize = true;
            this.labelOpisanie.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelOpisanie.Location = new System.Drawing.Point(3, 20);
            this.labelOpisanie.Name = "labelOpisanie";
            this.labelOpisanie.Size = new System.Drawing.Size(55, 15);
            this.labelOpisanie.TabIndex = 2;
            this.labelOpisanie.Text = "Описание";
            // 
            // pictureBoxPhoto
            // 
            this.pictureBoxPhoto.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxPhoto.Name = "pictureBoxPhoto";
            this.pictureBoxPhoto.Size = new System.Drawing.Size(152, 168);
            this.pictureBoxPhoto.TabIndex = 3;
            this.pictureBoxPhoto.TabStop = false;
            // 
            // ProductCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBoxPhoto);
            this.Controls.Add(this.Tip);
            this.Controls.Add(this.pRight);
            this.Name = "ProductCard";
            this.Size = new System.Drawing.Size(970, 176);
            this.Load += new System.EventHandler(this.ProductCard_Load);
            this.pRight.ResumeLayout(false);
            this.pRight.PerformLayout();
            this.Tip.ResumeLayout(false);
            this.Tip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pRight;
        private System.Windows.Forms.TableLayoutPanel Tip;
        private System.Windows.Forms.PictureBox pictureBoxPhoto;
        private System.Windows.Forms.Label labelHeader;
        private System.Windows.Forms.Label labelKol;
        private System.Windows.Forms.Label labelEd2;
        private System.Windows.Forms.Label labelEd;
        private System.Windows.Forms.Label labelPrice2;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelPostav2;
        private System.Windows.Forms.Label labelPostav;
        private System.Windows.Forms.Label labelProizvod2;
        private System.Windows.Forms.Label labelProizvod;
        private System.Windows.Forms.Label labelOpisanie2;
        private System.Windows.Forms.Label labelHeader2;
        private System.Windows.Forms.Label labelOpisanie;
        private System.Windows.Forms.Label labelKol2;
        private System.Windows.Forms.Label labelDiscountValue;
    }
}
