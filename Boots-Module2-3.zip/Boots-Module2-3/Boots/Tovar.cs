﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using Boots.Data;

namespace Boots
{
    public partial class Tovar : Form
    {
        private static string connectString = @"Server=alla\\allooo;Database=Магазин обувки;Trusted_Connection=True;";

        private List<Product> _allproducts = new List<Product>();
        private readonly ProductRepository _repo = new ProductRepository();

        public Tovar()
        {
            InitializeComponent();
            this.Load += Tovar_Load;
        }

        private void Tovar_Load(object sender, EventArgs e)
        {
            pTools.Visible = true;
            pTools.BringToFront();

            labelUser.Text = "Пользователь: " +
                (string.IsNullOrWhiteSpace(LoginClass.UserName) ? "Гость" : LoginClass.UserName);

            ApplyPoileUi();
            ReloadProducts();
        }

        private void ApplyPoileUi()
        {
            bool allowed = LoginClass.Role == LoginClass.UserRole.Manager ||
                           LoginClass.Role == LoginClass.UserRole.Admin;

            //pTools.Visible = allowed;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginClass.UserName = "Гость";
            LoginClass.Role = LoginClass.UserRole.Guest;

            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void ReloadProducts()
        {
            _allproducts = _repo.GetAll();
            ShowProducts(_allproducts);
        }

        private bool Contains(string value, string token)
        {
            if (string.IsNullOrEmpty(value)) return false;
            return value.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void ShowProducts(List<Product> items)
        {
            flpProducts.SuspendLayout();
            flpProducts.Controls.Clear();

            foreach (var p in items)
            {
                var card = new ProductCard();
                card.SetData(p);
                flpProducts.Controls.Add(card);
            }

            flpProducts.ResumeLayout();
        }

        private bool ContainsInAnyTexField(Product p, string token)
        {
            return Contains(p.Articul, token) ||
                   Contains(p.Discription, token) ||
                   Contains(p.Manufacturer, token) ||
                   Contains(p.Supplier, token) ||
                   Contains(p.Name, token) ||
                   Contains(p.Unit, token);
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void pTools_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}