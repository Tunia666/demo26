﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using Demka;

namespace Demka
{
    public partial class Form1 : Form
    {
        private AuthService _authService;
        private const string ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Учет_продуктов_2;Integrated Security=True";
        public Form1()
        {

            InitializeComponent();
            _authService = new AuthService();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.AcceptButton = button1; 
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text.Trim();  
            string password = textBox2.Text;
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните все поля.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; 
            }
            User user = _authService.AuthenticateUser(login, password);
            if (user != null)
            {
                MessageBox.Show($"Добро пожаловать, {user.Login}!\nВаша роль: {user.RoleName}",
                    "Успешный вход", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Form2 form2 = new Form2();
                form2.Show();
                this.Hide(); 
            }
            else
            {
                MessageBox.Show("Неправильный логин или пароль.", "Ошибка входа",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Clear(); 
                textBox2.Focus(); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text;
            string password = textBox2.Text;
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните все поля.");
                return;
            }
            if (RegisterUser(login, password))
            {
                MessageBox.Show("Регистрация прошла успешно!");
            }
        }
        private bool RegisterUser(string login, string password)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                    string checkQuery = "SELECT COUNT(*) FROM Пользователи WHERE Логин = @Username";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Username", login);
                        int userCount = (int)checkCommand.ExecuteScalar();

                        if (userCount > 0)
                        {
                            MessageBox.Show("Пользователь с таким логином уже существует.");
                            return false;
                        }
                    }
                    string insertQuery = "INSERT INTO Пользователи (Логин, Пароль) VALUES (@Username, @Password)";
                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@Username", login);
                        insertCommand.Parameters.AddWithValue("@Password", password);

                        insertCommand.ExecuteNonQuery();

                        return true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка." + ex.Message);
                    return false;
                }
            }
        }
    }
}