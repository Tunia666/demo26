﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demka
{
    public enum UserRole
    {
        Admin = 1,
        Manager = 2
    }
    public class User
    {
        public int UserID { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public static User CurrentUser { get; set; }

        public bool HasRole(UserRole role)
        {
            return RoleID == (int)role;
        }
        public bool HasAnyRole(params UserRole[] roles)
        {
            foreach (var role in roles)
            {
                if (RoleID == (int)role) return true;
            }
            return false;
        }
        public bool IsAdmin => RoleID == (int)UserRole.Admin;
        public bool IsManager => RoleID == (int)UserRole.Manager;

        public List<string> GetAvailableModules()
        {
            var modules = new List<string>();

            switch ((UserRole)RoleID)
            {
                case UserRole.Admin:
                    modules.AddRange(new[] { "Просмотр заказов", "Просмотр товаров" });
                    break;
                case UserRole.Manager:
                    modules.AddRange(new[] { "Просмотр заказов", "Просмотр товаров" });
                    break;
            }

            return modules;
        }
    }

}
