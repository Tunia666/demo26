﻿using Demka;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demka
{
    public class AuthService
    {
        private const string ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Учет_продуктов_2;Integrated Security=True";

        /// <param name="login">Логин пользователя</param>
        /// <param name="password">Пароль пользователя</param>
        public User AuthenticateUser(string login, string password)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            u.ID_пользователя,
                            u.Логин,
                            u.ID_роли,
                            r.Наименование_роли
                        FROM Пользователи u
                        INNER JOIN Роли r ON u.ID_роли = r.ID_роли
                        WHERE u.Логин = @Login AND u.Пароль = @Password";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Login", login);
                        command.Parameters.AddWithValue("@Password", password);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                User user = new User
                                {
                                    UserID = Convert.ToInt32(reader["ID_пользователя"]),
                                    Login = reader["Логин"].ToString(),
                                    RoleID = Convert.ToInt32(reader["ID_роли"]),
                                    RoleName = reader["Наименование_роли"].ToString()
                                };

                                User.CurrentUser = user;

                                return user;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при подключении к базе данных: {ex.Message}",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return null;
        }

        public User GetUserById(int userId)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();

                    string query = @"
                        SELECT 
                            u.ID_пользователя,
                            u.Логин,
                            u.ID_роли,
                            r.Наименование_роли
                        FROM Пользователи u
                        INNER JOIN Роли r ON u.ID_роли = r.ID_роли
                        WHERE u.ID_пользователя = @UserId";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserId", userId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new User
                                {
                                    UserID = Convert.ToInt32(reader["ID_пользователя"]),
                                    Login = reader["Логин"].ToString(),
                                    RoleID = Convert.ToInt32(reader["ID_роли"]),
                                    RoleName = reader["Наименование_роли"].ToString()
                                };
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return null;
        }
        public static bool IsAuthenticated()
        {
            return User.CurrentUser != null;
        }
        public static void Logout()
        {
            User.CurrentUser = null;
        }
        public User RefreshCurrentUser()
        {
            if (User.CurrentUser == null) return null;
            return GetUserById(User.CurrentUser.UserID);
        }

    }
}
