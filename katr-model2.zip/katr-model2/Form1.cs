using System;
using System.Data.SqlClient;
using System.Data.SqlTypes;



namespace katr
{
    public partial class Auth : Form
    {
        public Auth()
        {
            InitializeComponent();
        }
        static string connectString = @"Data Source=172.19.235.170;Initial Catalog=����;User ID=stud;Password=1234;Encrypt=True;Trust Server Certificate=True";
        SqlConnection sqlConnection = new SqlConnection(connectString);
        private SqlConnection connection;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("������� ����� � ������.", "������", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectString)) ;
                {
                    sqlConnection.Open();
                    string sql = @"Select * [���� ����������] As RoleName,LTRIM(RTRIM(ISNULL([�������],''))) + '',
                    + LTRIM(RTRIM(ISNULL([���],''))) + '',+ LTRIM(RTRIM(ISNULL([��������],'')))
                       AS FIO From[������������] Where [�����] = @login And [������] = @password";
                    using (SqlCommand cmd = new SqlCommand(sql, connection))
                    {
                        cmd.Parameters.AddWithValue("@login", login);
                        cmd.Parameters.AddWithValue("@Password", password);

                        using (var r = cmd.ExecuteReader())
                        {
                            if (r.Read())
                            {
                                
                            }


                        }


                    }
                }

            }
            catch (Exception ex) 
            { 

            }
            
        }
    }
}
