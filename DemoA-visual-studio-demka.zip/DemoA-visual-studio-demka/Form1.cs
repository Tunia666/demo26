﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Demo2
{
    public partial class Auth : Form
    {
        public Auth()
        {
            InitializeComponent();
        }
        static string connectionString = @"Data Source=172.19.235.170;Initial Catalog=demo26.2;User ID=stud;Password=1234";
        SqlConnection myConnection = new SqlConnection(connectionString);
        Tovar tovar = new Tovar();
        private void buttoAuth_Click(object sender, EventArgs e)
        {
            string login = textBoxLogin.Text.Trim();
            string password = textBoxPassword.Text.Trim();
            try {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = @"select top 1 [Роль сотрудника] as RoleName, LTRIM(RTRIM(ISNULL([Фамилия],'')))+' '+LTRIM(RTRIM(ISNULL([Имя],'')))+' '+LTRIM(RTRIM(ISNULL([Отчество],''))) as FIO from [Users] where [Логин] = @login and [Пароль] = @password";
                    using (SqlCommand cmd = new SqlCommand(sql, connection)) {
                        cmd.Parameters.AddWithValue("@login", login);
                        cmd.Parameters.AddWithValue("@password", password);
                        using (var r = cmd.ExecuteReader()) {
                            if (r.Read())
                            {
                                string roleName = Convert.ToString(r["RoleName"]);
                                string fio = Convert.ToString(r["FIO"]);
                                //
                                //

                                MessageBox.Show("Успех");
                                
                                tovar.Show();
                            }
                            else {
                                MessageBox.Show("Неверный логин или пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                    }
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения/запроса"+ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonGuest_Click(object sender, EventArgs e)
        {
            tovar.Show();
        }
    }
}
