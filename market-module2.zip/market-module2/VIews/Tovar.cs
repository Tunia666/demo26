﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace market.VIews
{
    public partial class Tovar : Form
    {
        static string connectionString = @"Data Source=SASHA;Initial Catalog=market_shoes;Integrated Security=True;Encrypt=False";
        SqlConnection connection = new SqlConnection(connectionString);
       private List<Product> _products = new List<Product>();
        private readonly ProductRepository repository = new ProductRepository();
        public Tovar()
        {
            InitializeComponent();
        }

        private void Tovar_Load(object sender, EventArgs e)
        {
            labelUser.Text = "Пользователь: " + LoginClass.UserName;
            ApplyPoileUi();
            ReloadProducts();
        }
        private void ApplyPoileUi()
        {
            bool allowed = LoginClass.Role == LoginClass.UserRole.Admin || LoginClass.Role == LoginClass.UserRole.Manager;
            pTools.Visible = allowed;

        }

        private void ReloadProducts()
        {
            _products = repository.GetAll();
            ShowProducts(_products);
        }
        private void ShowProducts(List<Product> products) 
        {
            pProducts.SuspendLayout();
            pProducts.Controls.Clear();

            foreach (var p in products) 
            {
                var card = new ProductCard();
                card.SetData(p);
                pProducts.Controls.Add(card);
            }
            pProducts.ResumeLayout();
        }


        //public List<string> GetSuppliers()
        //{
        //    var res = new List<string>();
        //}



        private void btnLog_Click(object sender, EventArgs e)
        {
           Auth auth = new Auth();
            auth.Show();
            this.Hide();
        }
    }
}
