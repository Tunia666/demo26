﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace market.VIews
{
    public partial class ProductCard : UserControl
    {
        public int ProductId { get; set; }
        public ProductCard()
        {
            InitializeComponent();
        }


        public void SetData(Product p)
        {
            if (p == null)
            {
                throw new ArgumentNullException();
            }
            ProductId = p.Id;
            headerTXT.Text = $"{p.Category} | {p.Name}";
            descriptionTXT.Text = p.Description;
            makerTXT.Text = p.Manufacturer;
            postTXT.Text = p.Supplier;
            discountValue.Text = $"Действующая скидка: {p.Discount}%";
            // costTXT.Text =  p.Price.ToString();


            if (p.Discount > 0)
            {
                costNewOldPanel.Visible = true;
                oldCostTXT.Text = $"{p.Price} р.";
                costTXT.ForeColor = Color.Red;
                costTXT.Font = new Font(costTXT.Font, FontStyle.Strikeout);
                var newPrice = p.Price * (1 - p.Discount / 100);
                costTXT.Text = $"{newPrice} р.";
                newCostTXT.ForeColor = Color.Red;
                newCostTXT.Font = new Font(costTXT.Font, FontStyle.Strikeout);
                newCostTXT.Text = $"{newPrice} р.";
            }

            if (p.StrockQty <= 0)
            {
                BackColor = Color.LightSkyBlue;
            }
            else if (p.Discount > 15)
            {
                BackColor = ColorTranslator.FromHtml("#2E8B57");
            }
            else
            {
                BackColor = Color.White;
            }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void trip_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
