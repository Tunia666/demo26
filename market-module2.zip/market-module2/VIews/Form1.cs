﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
//using System.Data.SqlClient;

namespace market.VIews
{
    public partial class Auth : Form
    {
        static string connectionString = @"Data Source=SASHA;Initial Catalog=market_shoes;Integrated Security=True;Encrypt=False";
        SqlConnection connection = new SqlConnection(connectionString);
        private LoginClass.UserRole ParseRole(string roleName)
        {
            if (string.IsNullOrEmpty(roleName)) 
            {
                return LoginClass.UserRole.Guest;
            }
            roleName = roleName.Trim().ToLower();
            if (roleName.Contains("администратор"))
            {
                return LoginClass.UserRole.Admin;
            }
            if (roleName.Contains("менеджер"))
            {
                return LoginClass.UserRole.Manager;
            }
            if (roleName.Contains("авторизованный клиент"))
            {
                return LoginClass.UserRole.Client;
            }
            return LoginClass.UserRole.Guest;
        }
        public Auth()
        {
            InitializeComponent();

        }

        private void enter_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("click");

            string userLogin = login.Text.Trim();
            string userPassword = password.Text.Trim();

            if (string.IsNullOrWhiteSpace(userLogin) || string.IsNullOrWhiteSpace(userPassword))
            {
                MessageBox.Show("Введите логин и пароль");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    Debug.WriteLine("Соединение открыто");

                    string sql = @"
                SELECT TOP 1
                    [Role] AS RoleName,
                    LTRIM(RTRIM(ISNULL([UserSurname], ''))) + ' ' +
                    LTRIM(RTRIM(ISNULL([UserName], ''))) + ' ' +
                    LTRIM(RTRIM(ISNULL([UserPatronymic], ''))) AS FIO
                FROM [dbo].[User$]
                WHERE [Login] = @userLogin
                  AND [Password] = @userPassword";

                    using (SqlCommand cmd = new SqlCommand(sql, connection))
                    {
                        cmd.Parameters.Add("@userLogin", System.Data.SqlDbType.NVarChar).Value = userLogin;
                        cmd.Parameters.Add("@userPassword", System.Data.SqlDbType.NVarChar).Value = userPassword;

                        using (SqlDataReader r = cmd.ExecuteReader())
                        {
                            if (r.Read())
                            {
                                string roleName = r["RoleName"]?.ToString();
                                string fio = r["FIO"]?.ToString();

                                Debug.WriteLine(roleName + " " + fio);
                                LoginClass.UserName = string.IsNullOrWhiteSpace(fio) ? userLogin : fio;
                                LoginClass.Role = ParseRole(roleName);
                                MessageBox.Show("Успешный вход");

                                Tovar tovar = new Tovar();
                                tovar.Show();

                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
                Debug.WriteLine(ex.ToString());
            }
        }


    }
}
