﻿namespace market.VIews
{
    partial class ProductCard
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            generalP = new FlowLayoutPanel();
            productPicture = new PictureBox();
            trip = new TableLayoutPanel();
            ammountTXT = new Label();
            edinTXT = new Label();
            costTXT = new Label();
            postTXT = new Label();
            makerTXT = new Label();
            descriptionTXT = new Label();
            headerTXT = new Label();
            labelHeader = new Label();
            description = new Label();
            maker = new Label();
            post = new Label();
            cost = new Label();
            edin = new Label();
            ammount = new Label();
            pRight = new Panel();
            costNewOldPanel = new TableLayoutPanel();
            newCostTXT = new Label();
            oldCostTXT = new Label();
            oldCost = new Label();
            newCost = new Label();
            discountValue = new Label();
            generalP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)productPicture).BeginInit();
            trip.SuspendLayout();
            pRight.SuspendLayout();
            costNewOldPanel.SuspendLayout();
            SuspendLayout();
            // 
            // generalP
            // 
            generalP.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            generalP.Controls.Add(productPicture);
            generalP.Controls.Add(trip);
            generalP.Controls.Add(pRight);
            generalP.Dock = DockStyle.Fill;
            generalP.Location = new Point(0, 0);
            generalP.Name = "generalP";
            generalP.Size = new Size(869, 220);
            generalP.TabIndex = 2;
            generalP.Paint += flowLayoutPanel1_Paint;
            // 
            // productPicture
            // 
            productPicture.Location = new Point(3, 3);
            productPicture.Name = "productPicture";
            productPicture.Size = new Size(179, 214);
            productPicture.TabIndex = 0;
            productPicture.TabStop = false;
            // 
            // trip
            // 
            trip.ColumnCount = 2;
            trip.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42.71255F));
            trip.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57.28745F));
            trip.Controls.Add(ammountTXT, 1, 6);
            trip.Controls.Add(edinTXT, 1, 5);
            trip.Controls.Add(costTXT, 1, 4);
            trip.Controls.Add(postTXT, 1, 3);
            trip.Controls.Add(makerTXT, 1, 2);
            trip.Controls.Add(descriptionTXT, 1, 1);
            trip.Controls.Add(headerTXT, 1, 0);
            trip.Controls.Add(labelHeader, 0, 0);
            trip.Controls.Add(description, 0, 1);
            trip.Controls.Add(maker, 0, 2);
            trip.Controls.Add(post, 0, 3);
            trip.Controls.Add(cost, 0, 4);
            trip.Controls.Add(edin, 0, 5);
            trip.Controls.Add(ammount, 0, 6);
            trip.Location = new Point(188, 3);
            trip.Name = "trip";
            trip.RowCount = 7;
            trip.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            trip.RowStyles.Add(new RowStyle(SizeType.Absolute, 47F));
            trip.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            trip.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            trip.RowStyles.Add(new RowStyle(SizeType.Absolute, 31F));
            trip.RowStyles.Add(new RowStyle(SizeType.Absolute, 27F));
            trip.RowStyles.Add(new RowStyle(SizeType.Absolute, 23F));
            trip.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            trip.Size = new Size(494, 214);
            trip.TabIndex = 1;
            trip.Paint += trip_Paint;
            // 
            // ammountTXT
            // 
            ammountTXT.AutoSize = true;
            ammountTXT.Font = new Font("Times New Roman", 8.2F);
            ammountTXT.Location = new Point(214, 196);
            ammountTXT.Margin = new Padding(3, 5, 3, 0);
            ammountTXT.Name = "ammountTXT";
            ammountTXT.Size = new Size(0, 16);
            ammountTXT.TabIndex = 13;
            // 
            // edinTXT
            // 
            edinTXT.AutoSize = true;
            edinTXT.Font = new Font("Times New Roman", 8.2F);
            edinTXT.Location = new Point(214, 169);
            edinTXT.Margin = new Padding(3, 5, 3, 0);
            edinTXT.Name = "edinTXT";
            edinTXT.Size = new Size(0, 16);
            edinTXT.TabIndex = 12;
            // 
            // costTXT
            // 
            costTXT.AutoSize = true;
            costTXT.Font = new Font("Times New Roman", 8.2F);
            costTXT.Location = new Point(214, 138);
            costTXT.Margin = new Padding(3, 5, 3, 0);
            costTXT.Name = "costTXT";
            costTXT.Size = new Size(0, 16);
            costTXT.TabIndex = 11;
            // 
            // postTXT
            // 
            postTXT.AutoSize = true;
            postTXT.Font = new Font("Times New Roman", 8.2F);
            postTXT.Location = new Point(214, 110);
            postTXT.Margin = new Padding(3, 5, 3, 0);
            postTXT.Name = "postTXT";
            postTXT.Size = new Size(0, 16);
            postTXT.TabIndex = 10;
            // 
            // makerTXT
            // 
            makerTXT.AutoSize = true;
            makerTXT.Font = new Font("Times New Roman", 8.2F);
            makerTXT.Location = new Point(214, 81);
            makerTXT.Margin = new Padding(3, 5, 3, 0);
            makerTXT.Name = "makerTXT";
            makerTXT.Size = new Size(0, 16);
            makerTXT.TabIndex = 9;
            // 
            // descriptionTXT
            // 
            descriptionTXT.AutoSize = true;
            descriptionTXT.Font = new Font("Times New Roman", 8.2F);
            descriptionTXT.Location = new Point(214, 34);
            descriptionTXT.Margin = new Padding(3, 5, 3, 0);
            descriptionTXT.Name = "descriptionTXT";
            descriptionTXT.Size = new Size(0, 16);
            descriptionTXT.TabIndex = 8;
            // 
            // headerTXT
            // 
            headerTXT.AutoSize = true;
            headerTXT.Font = new Font("Times New Roman", 8.2F);
            headerTXT.Location = new Point(214, 5);
            headerTXT.Margin = new Padding(3, 5, 3, 0);
            headerTXT.Name = "headerTXT";
            headerTXT.Size = new Size(0, 16);
            headerTXT.TabIndex = 7;
            // 
            // labelHeader
            // 
            labelHeader.AutoSize = true;
            labelHeader.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelHeader.Location = new Point(3, 5);
            labelHeader.Margin = new Padding(3, 5, 3, 0);
            labelHeader.Name = "labelHeader";
            labelHeader.Size = new Size(198, 15);
            labelHeader.TabIndex = 0;
            labelHeader.Text = "Категория | Наименование товара";
            // 
            // description
            // 
            description.AutoSize = true;
            description.Font = new Font("Times New Roman", 8.2F);
            description.Location = new Point(3, 34);
            description.Margin = new Padding(3, 5, 3, 0);
            description.Name = "description";
            description.Size = new Size(64, 16);
            description.TabIndex = 1;
            description.Text = "Описание";
            // 
            // maker
            // 
            maker.AutoSize = true;
            maker.Font = new Font("Times New Roman", 8.2F);
            maker.Location = new Point(3, 81);
            maker.Margin = new Padding(3, 5, 3, 0);
            maker.Name = "maker";
            maker.Size = new Size(95, 16);
            maker.TabIndex = 2;
            maker.Text = "Производитель";
            // 
            // post
            // 
            post.AutoSize = true;
            post.Font = new Font("Times New Roman", 8.2F);
            post.Location = new Point(3, 110);
            post.Margin = new Padding(3, 5, 3, 0);
            post.Name = "post";
            post.Size = new Size(73, 16);
            post.TabIndex = 3;
            post.Text = "Поставщик";
            // 
            // cost
            // 
            cost.AutoSize = true;
            cost.Font = new Font("Times New Roman", 8.2F);
            cost.Location = new Point(3, 138);
            cost.Margin = new Padding(3, 5, 3, 0);
            cost.Name = "cost";
            cost.Size = new Size(35, 16);
            cost.TabIndex = 4;
            cost.Text = "Цена";
            // 
            // edin
            // 
            edin.AutoSize = true;
            edin.Font = new Font("Times New Roman", 8.2F);
            edin.Location = new Point(3, 169);
            edin.Margin = new Padding(3, 5, 3, 0);
            edin.Name = "edin";
            edin.Size = new Size(56, 16);
            edin.TabIndex = 5;
            edin.Text = "Единица";
            // 
            // ammount
            // 
            ammount.AutoSize = true;
            ammount.Font = new Font("Times New Roman", 8.2F);
            ammount.Location = new Point(3, 196);
            ammount.Margin = new Padding(3, 5, 3, 0);
            ammount.Name = "ammount";
            ammount.Size = new Size(75, 16);
            ammount.TabIndex = 6;
            ammount.Text = "Количество";
            // 
            // pRight
            // 
            pRight.Controls.Add(costNewOldPanel);
            pRight.Controls.Add(discountValue);
            pRight.Location = new Point(688, 3);
            pRight.Name = "pRight";
            pRight.Size = new Size(178, 212);
            pRight.TabIndex = 2;
            // 
            // costNewOldPanel
            // 
            costNewOldPanel.ColumnCount = 2;
            costNewOldPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            costNewOldPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            costNewOldPanel.Controls.Add(newCostTXT, 1, 1);
            costNewOldPanel.Controls.Add(oldCostTXT, 1, 0);
            costNewOldPanel.Controls.Add(oldCost, 0, 0);
            costNewOldPanel.Controls.Add(newCost, 0, 1);
            costNewOldPanel.Location = new Point(0, 110);
            costNewOldPanel.Margin = new Padding(0, 3, 3, 3);
            costNewOldPanel.Name = "costNewOldPanel";
            costNewOldPanel.RowCount = 2;
            costNewOldPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            costNewOldPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            costNewOldPanel.Size = new Size(181, 57);
            costNewOldPanel.TabIndex = 15;
            costNewOldPanel.Visible = false;
            // 
            // newCostTXT
            // 
            newCostTXT.AutoSize = true;
            newCostTXT.Font = new Font("Times New Roman", 8.2F);
            newCostTXT.Location = new Point(93, 33);
            newCostTXT.Margin = new Padding(3, 5, 3, 0);
            newCostTXT.Name = "newCostTXT";
            newCostTXT.Size = new Size(0, 16);
            newCostTXT.TabIndex = 17;
            // 
            // oldCostTXT
            // 
            oldCostTXT.AutoSize = true;
            oldCostTXT.Font = new Font("Times New Roman", 8.2F);
            oldCostTXT.Location = new Point(93, 5);
            oldCostTXT.Margin = new Padding(3, 5, 3, 0);
            oldCostTXT.Name = "oldCostTXT";
            oldCostTXT.Size = new Size(0, 16);
            oldCostTXT.TabIndex = 16;
            // 
            // oldCost
            // 
            oldCost.AutoSize = true;
            oldCost.Font = new Font("Times New Roman", 8.2F);
            oldCost.Location = new Point(3, 5);
            oldCost.Margin = new Padding(3, 5, 3, 0);
            oldCost.Name = "oldCost";
            oldCost.Size = new Size(76, 16);
            oldCost.TabIndex = 14;
            oldCost.Text = "Старая цена";
            oldCost.Click += label1_Click;
            // 
            // newCost
            // 
            newCost.AutoSize = true;
            newCost.Font = new Font("Times New Roman", 8.2F);
            newCost.Location = new Point(3, 33);
            newCost.Margin = new Padding(3, 5, 3, 0);
            newCost.Name = "newCost";
            newCost.Size = new Size(72, 16);
            newCost.TabIndex = 15;
            newCost.Text = "Новая цена";
            // 
            // discountValue
            // 
            discountValue.AutoSize = true;
            discountValue.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            discountValue.Location = new Point(3, 5);
            discountValue.Margin = new Padding(3, 5, 3, 0);
            discountValue.Name = "discountValue";
            discountValue.Size = new Size(130, 15);
            discountValue.TabIndex = 14;
            discountValue.Text = "Действующая скидка";
            // 
            // ProductCard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(generalP);
            Name = "ProductCard";
            Size = new Size(869, 220);
            generalP.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)productPicture).EndInit();
            trip.ResumeLayout(false);
            trip.PerformLayout();
            pRight.ResumeLayout(false);
            pRight.PerformLayout();
            costNewOldPanel.ResumeLayout(false);
            costNewOldPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel generalP;
        private PictureBox productPicture;
        private TableLayoutPanel trip;
        private Panel pRight;
        private Label labelHeader;
        private Label description;
        private Label maker;
        private Label post;
        private Label cost;
        private Label edin;
        private Label ammount;
        private Label ammountTXT;
        private Label edinTXT;
        private Label costTXT;
        private Label postTXT;
        private Label makerTXT;
        private Label descriptionTXT;
        private Label headerTXT;
        private Label discountValue;
        private TableLayoutPanel costNewOldPanel;
        private Label oldCost;
        private Label newCostTXT;
        private Label oldCostTXT;
        private Label newCost;
    }
}
