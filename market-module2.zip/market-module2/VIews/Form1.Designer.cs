﻿namespace market.VIews
{
    partial class Auth
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            enter = new Button();
            log = new Label();
            passw = new Label();
            guest = new Button();
            login = new TextBox();
            password = new TextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // enter
            // 
            enter.Font = new Font("Times New Roman", 16.2F);
            enter.Location = new Point(186, 245);
            enter.Name = "enter";
            enter.Size = new Size(115, 76);
            enter.TabIndex = 0;
            enter.Text = "Войти";
            enter.UseVisualStyleBackColor = true;
            enter.Click += enter_Click;
            // 
            // log
            // 
            log.AutoSize = true;
            log.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 204);
            log.Location = new Point(153, 124);
            log.Name = "log";
            log.Size = new Size(88, 33);
            log.TabIndex = 1;
            log.Text = "Логин\r\n";
            // 
            // passw
            // 
            passw.AutoSize = true;
            passw.Font = new Font("Times New Roman", 16.2F);
            passw.Location = new Point(153, 182);
            passw.Name = "passw";
            passw.Size = new Size(101, 33);
            passw.TabIndex = 2;
            passw.Text = "Пароль";
            // 
            // guest
            // 
            guest.Font = new Font("Times New Roman", 16.2F);
            guest.Location = new Point(387, 245);
            guest.Name = "guest";
            guest.Size = new Size(115, 76);
            guest.TabIndex = 3;
            guest.Text = "Гость";
            guest.UseVisualStyleBackColor = true;
            // 
            // login
            // 
            login.Location = new Point(258, 124);
            login.Name = "login";
            login.Size = new Size(204, 27);
            login.TabIndex = 4;
            // 
            // password
            // 
            password.Location = new Point(258, 187);
            password.Name = "password";
            password.Size = new Size(204, 27);
            password.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Icon;
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 122);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // Auth
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(705, 385);
            Controls.Add(pictureBox1);
            Controls.Add(password);
            Controls.Add(login);
            Controls.Add(guest);
            Controls.Add(passw);
            Controls.Add(log);
            Controls.Add(enter);
            Name = "Auth";
            Text = "Autorisation";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button enter;
        private Label log;
        private Label passw;
        private Button guest;
        private TextBox login;
        private TextBox password;
        private PictureBox pictureBox1;
    }
}