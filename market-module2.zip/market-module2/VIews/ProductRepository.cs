﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace market.VIews
{
    public class ProductRepository
    {
        static string connectionString = @"Data Source=SASHA;Initial Catalog=market_shoes;Integrated Security=True;Encrypt=False";
        SqlConnection connection = new SqlConnection(connectionString);

        public List<Product> GetAll()
        {
            var products = new List<Product>();

            using (SqlConnection connection = new SqlConnection(connectionString)) 
            {
                 
                using (var cmd = new SqlCommand(@"select [ProductID] as Id, 
                     [ProductArticleNumber] as Articule,
                     [ProductName] as Name, 
                     [Unit] as Unit, 
                     [Cost] as Cost, 
                     [Manufacturer] as Manufacturer, 
                     [Supplier] as Supplier, 
                     [Category] as Category, 
                     [DiscountAmount] as Discount, 
                     [QuantityInStock] as StrockQty, 
                     [Description] as Description, 
                     [Photo] as Photo 
 from [dbo].[Product$];", connection)) 
                {
                    connection.Open();
                    using (var r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            products.Add(new Product
                            {
                                Id = Convert.ToInt32(r["Id"]),
                                Articule = Convert.ToString(r["Articule"]),
                                Name = Convert.ToString(r["Name"]),
                                Category = Convert.ToString(r["Category"]),
                                Manufacturer = Convert.ToString(r["Manufacturer"]),
                                Supplier = Convert.ToString(r["Supplier"]), 
                                Description = Convert.ToString(r["Description"]),
                                StrockQty = Convert.ToInt32(r["StrockQty"]),
                                Discount = Convert.ToInt32(r["Discount"]),
                                Price = Convert.ToDecimal(r["Cost"]),
                                Unit = Convert.ToString(r["Unit"]),
                                ImagePath = Convert.ToString(r["Photo"])

                               
                            });
                        }
                    }
                }  
            
            }
            return products;
        }
    }
}
