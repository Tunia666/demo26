﻿namespace market.VIews
{
    partial class Tovar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pTop = new Panel();
            btnLog = new Button();
            labelUser = new Label();
            label1 = new Label();
            pProducts = new FlowLayoutPanel();
            pTools = new Panel();
            sortQComboBox = new ComboBox();
            supplierComboBox = new ComboBox();
            searchTextBox = new TextBox();
            supplierLabel = new Label();
            label3 = new Label();
            searchLabel = new Label();
            pTop.SuspendLayout();
            pTools.SuspendLayout();
            SuspendLayout();
            // 
            // pTop
            // 
            pTop.Controls.Add(btnLog);
            pTop.Controls.Add(labelUser);
            pTop.Controls.Add(label1);
            pTop.Dock = DockStyle.Top;
            pTop.Location = new Point(0, 0);
            pTop.Name = "pTop";
            pTop.Size = new Size(904, 74);
            pTop.TabIndex = 0;
            // 
            // btnLog
            // 
            btnLog.Font = new Font("Times New Roman", 12.2F);
            btnLog.Location = new Point(752, 9);
            btnLog.Name = "btnLog";
            btnLog.Size = new Size(94, 29);
            btnLog.TabIndex = 2;
            btnLog.Text = "Выход";
            btnLog.UseVisualStyleBackColor = true;
            btnLog.Click += btnLog_Click;
            // 
            // labelUser
            // 
            labelUser.AutoSize = true;
            labelUser.Font = new Font("Times New Roman", 12.2F);
            labelUser.Location = new Point(300, 9);
            labelUser.Name = "labelUser";
            labelUser.Size = new Size(137, 23);
            labelUser.TabIndex = 1;
            labelUser.Text = "Пользователь:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 16.2F);
            label1.Location = new Point(3, 2);
            label1.Name = "label1";
            label1.Size = new Size(203, 33);
            label1.TabIndex = 0;
            label1.Text = "Список товаров";
            // 
            // pProducts
            // 
            pProducts.AutoScroll = true;
            pProducts.Location = new Point(3, 163);
            pProducts.Name = "pProducts";
            pProducts.Size = new Size(897, 414);
            pProducts.TabIndex = 1;
            // 
            // pTools
            // 
            pTools.Controls.Add(sortQComboBox);
            pTools.Controls.Add(supplierComboBox);
            pTools.Controls.Add(searchTextBox);
            pTools.Controls.Add(supplierLabel);
            pTools.Controls.Add(label3);
            pTools.Controls.Add(searchLabel);
            pTools.Location = new Point(3, 83);
            pTools.Name = "pTools";
            pTools.Size = new Size(897, 74);
            pTools.TabIndex = 1;
            // 
            // sortQComboBox
            // 
            sortQComboBox.FormattingEnabled = true;
            sortQComboBox.Location = new Point(641, 11);
            sortQComboBox.Name = "sortQComboBox";
            sortQComboBox.Size = new Size(151, 28);
            sortQComboBox.TabIndex = 8;
            // 
            // supplierComboBox
            // 
            supplierComboBox.FormattingEnabled = true;
            supplierComboBox.Location = new Point(369, 10);
            supplierComboBox.Name = "supplierComboBox";
            supplierComboBox.Size = new Size(151, 28);
            supplierComboBox.TabIndex = 7;
            // 
            // searchTextBox
            // 
            searchTextBox.Location = new Point(78, 11);
            searchTextBox.Name = "searchTextBox";
            searchTextBox.Size = new Size(155, 27);
            searchTextBox.TabIndex = 6;
            // 
            // supplierLabel
            // 
            supplierLabel.AutoSize = true;
            supplierLabel.Font = new Font("Times New Roman", 12.2F);
            supplierLabel.Location = new Point(252, 11);
            supplierLabel.Name = "supplierLabel";
            supplierLabel.Size = new Size(111, 23);
            supplierLabel.TabIndex = 5;
            supplierLabel.Text = "Поставщик";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12.2F);
            label3.Location = new Point(554, 16);
            label3.Name = "label3";
            label3.Size = new Size(81, 23);
            label3.TabIndex = 4;
            label3.Text = "Остаток";
            // 
            // searchLabel
            // 
            searchLabel.AutoSize = true;
            searchLabel.Font = new Font("Times New Roman", 12.2F);
            searchLabel.Location = new Point(6, 16);
            searchLabel.Name = "searchLabel";
            searchLabel.Size = new Size(66, 23);
            searchLabel.TabIndex = 3;
            searchLabel.Text = "Поиск";
            // 
            // Tovar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(904, 576);
            Controls.Add(pTools);
            Controls.Add(pProducts);
            Controls.Add(pTop);
            Name = "Tovar";
            Text = "Tovar";
            Load += Tovar_Load;
            pTop.ResumeLayout(false);
            pTop.PerformLayout();
            pTools.ResumeLayout(false);
            pTools.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pTop;
        private FlowLayoutPanel pProducts;
        private Panel pTools;
        private Label label1;
        private Label labelUser;
        private Button btnLog;
        private Label supplierLabel;
        private Label label3;
        private Label searchLabel;
        private TextBox searchTextBox;
        private ComboBox supplierComboBox;
        private ComboBox sortQComboBox;
    }
}