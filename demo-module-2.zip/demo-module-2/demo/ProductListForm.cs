using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo
{
    public partial class ProductListForm : Form
    {
        private List<ProductCardTemplate> cards = new List<ProductCardTemplate>();
        

        public ProductListForm()
        {
            InitializeComponent();

            // Инициализация фильтров
            cmbSort.SelectedIndex = 0;
            
            // Подгружаем поставщиков в фильтр
            try {
                cmbFilter.Items.Clear();
                cmbFilter.Items.Add("Все поставщики");
                var table = DatabaseContext.ExecuteQuery("SELECT DISTINCT Supplier FROM Product");
                foreach (DataRow r in table.Rows) cmbFilter.Items.Add(r[0].ToString());
                cmbFilter.SelectedIndex = 0;
            } catch {
                cmbFilter.Items.Add("Все поставщики");
                cmbFilter.SelectedIndex = 0;
            }
            
            pnlHeader.Visible = false; // Hide search/filter panel for Module 2

            LoadProducts();
            ApplyRolePermissions();
        }

        private void ApplyRolePermissions()
        {
            btnAddProduct.Visible = (CurrentUser.Role == "Администратор");
            btnOrders.Visible = (CurrentUser.Role == "Администратор" || CurrentUser.Role == "Менеджер");
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Раздел 'Заказы' находится в разработке.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            // Not implemented in Module 2
        }

        private void LoadProducts()
        {
            try
            {
                foreach (var card in cards) { flpProducts.Controls.Remove(card); card.Dispose(); }
                cards.Clear();

                string query = "SELECT * FROM Product";
                DataTable dt = DatabaseContext.ExecuteQuery(query);

                int count = 0;

                foreach (DataRow row in dt.Rows)
                {

                    var card = CreateProductCard(row);
                    cards.Add(card);
                    count++;
                }

                lblCount.Text = $"{count} из {dt.Rows.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private ProductCardTemplate CreateProductCard(DataRow row)
        {
            ProductCardTemplate card = new ProductCardTemplate();
            
            // Фото
            string photoName = row["Photo"] != DBNull.Value ? row["Photo"].ToString() : "";
            string fullPhotoPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "import", photoName);
            Image img = null;
            
            try {
                if (!string.IsNullOrEmpty(photoName) && System.IO.File.Exists(fullPhotoPath))
                    img = Image.FromFile(fullPhotoPath);
                else
                    img = Properties.Resources.non_picture;
            } catch { }

            int discount = row["DiscountAmount"] != DBNull.Value ? Convert.ToInt32(row["DiscountAmount"]) : 0;
            int stock = row["QuantityInStock"] != DBNull.Value ? Convert.ToInt32(row["QuantityInStock"]) : 0;
            decimal cost = Convert.ToDecimal(row["Cost"]);

            card.SetData(
                row["ProductName"].ToString(),
                row["Category"].ToString(),
                row["Description"].ToString(),
                row["Manufacturer"].ToString(),
                row["Supplier"].ToString(),
                row["Unit"].ToString(),
                cost,
                discount,
                stock,
                img
            );

            // Click handler disabled in Module 2

            flpProducts.Controls.Add(card);
            return card;
        }
    }
}
